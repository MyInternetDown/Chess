// knight.h

#ifndef KNIGHT_H
#define KNIGHT_H

#include "chesspiece.h"

class Knight : public ChessPiece {
public:
    // Constructor
    Knight(Coordinate pos, string white);

    // Override the getAllMoves function for the Knight
    void getAllMoves(ChessPiece* board[8][8])  override;

};

#endif
